# AdaptNXT
Data Scrapping from Quil.com

Gathering the product details from Quill website using jsoup and entering the details to the details to csv file using java.
java source code in directory:- src/com.quill
and csv file is below the src folder